#include <stdio.h>
#include <string.h>

void vulnerable_function(char *password) {
    char buffer[16];
    int pass = 0;

    // Usar strncpy en lugar de strcpy para prevenir buffer overflow
    strncpy(buffer, password, sizeof(buffer) - 1);
    buffer[sizeof(buffer) - 1] = '\0';  // Asegurar que el buffer est� null-terminated

    // Verificar el contenido del buffer
    printf("Buffer content: %s\n", buffer);

    // Verifica si la contrase�a es correcta
    if(strcmp(buffer, "secret") == 0) {
        printf("\nCorrect Password\n");
        pass = 1;
    } else {
        printf("\nIncorrect Password\n");
    }

    // Imprimir el valor de 'pass'
    printf("Pass value: %d\n", pass);

    // Si la contrase�a es correcta, da privilegios de root
    if(pass) {
        printf("\nRoot privileges given to the user\n");
    }
}

int main(int argc, char *argv[]) {
    if(argc < 2) {
        printf("Usage: %s <password>\n", argv[0]);
        return 1;
    }

    // Llama a la funci�n vulnerable con el argumento de l�nea de comandos
    vulnerable_function(argv[1]);

    return 0;
}
