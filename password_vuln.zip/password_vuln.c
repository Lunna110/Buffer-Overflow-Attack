#include <stdio.h>
#include <string.h>

void vulnerable_function(char *password) {
    char buffer[16];
    int pass = 0;

    // Copia la contrase�a ingresada en el buffer
    strcpy(buffer, password);

    // Verifica si la contrase�a es correcta
    if(strcmp(buffer, "secret") == 0) {
        printf("\n Correct Password \n");
        pass = 1;
    }

    // Si la contrase�a es correcta, da privilegios de root
    if(pass) {
        printf("\n Root privileges given to the user \n");
    }
}

int main(int argc, char *argv[]) {
    if(argc < 2) {
        printf("Usage: %s <password>\n", argv[0]);
        return 1;
    }

    // Llama a la funci�n vulnerable con el argumento de l�nea de comandos
    vulnerable_function(argv[1]);

    return 0;
}
